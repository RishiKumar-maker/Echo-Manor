# puzzles/

Puzzle definitions, puzzle state machines, and solution-checking logic belong here, one small module per puzzle. Interaction detection itself lives in interaction/, not here.
