# network/

PeerJS connection setup, peer-to-peer session management, and state synchronization for co-op play belong here. This folder is intentionally empty until the networking milestone.
