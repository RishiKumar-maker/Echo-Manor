# world/

Level geometry, room layouts, and static environment objects for the manor's interiors belong here. This includes loaders/builders that assemble Three.js scene content for each room or area. No gameplay or player logic belongs in this folder.
