# ui/

HTML/DOM-based UI — menus, HUD, dialogs — belongs here, kept separate from the Three.js scene. No Three.js objects or scene logic belong in this folder.
