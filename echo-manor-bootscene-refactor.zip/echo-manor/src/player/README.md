# player/

Player controller, movement, and input-handling logic belongs here. This includes the first-person camera rig that follows player input. No rendering or engine-level code belongs in this folder.
