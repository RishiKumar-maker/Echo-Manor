# save/

Save/load game state, serialization of progress and puzzle solutions, and persistence belong here. Keeps save-format concerns isolated from the gameplay code that produces the state.
