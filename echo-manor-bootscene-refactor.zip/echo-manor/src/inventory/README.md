# inventory/

Player inventory state and item data belong here — adding, removing, and using items. This is state and logic only; DOM-facing inventory UI belongs in ui/.
