# utils/

Small, generic, reusable helper functions that don't belong to any specific system — math helpers, formatting, and the like — belong here. Utilities should have no dependencies on game state.
