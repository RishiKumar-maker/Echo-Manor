# interaction/

Systems that detect and handle player interaction with objects — looking at, clicking, picking up — belong here. This includes raycasting helpers and interactable-object interfaces. Puzzle-specific logic belongs in puzzles/, not here.
