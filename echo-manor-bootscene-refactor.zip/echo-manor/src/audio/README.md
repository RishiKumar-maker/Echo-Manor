# audio/

Sound effect and music playback, audio listener setup, and volume/mixing controls belong here. This wraps Three.js's audio system or the Web Audio API for the rest of the engine to use.
